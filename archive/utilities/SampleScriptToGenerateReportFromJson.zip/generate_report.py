#!/usr/bin/env python3
"""
AIRA Report Generator
Generates dynamic HTML reports from Jinja2 templates and JSON data
"""

import json
import sys
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape

def generate_report(template_path, data_path, output_path):
    """
    Generate an HTML report from a Jinja2 template and JSON data
    
    Args:
        template_path (str): Path to the Jinja2 template file
        data_path (str): Path to the JSON data file
        output_path (str): Path for the generated HTML output
    """
    
    # Load JSON data
    try:
        with open(data_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f"✅ Loaded data from {data_path}")
    except FileNotFoundError:
        print(f"❌ Error: Data file {data_path} not found")
        return False
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON in {data_path}: {e}")
        return False
    
    # Setup Jinja2 environment
    template_dir = Path(template_path).parent
    template_name = Path(template_path).name
    
    env = Environment(
        loader=FileSystemLoader(template_dir),
        autoescape=select_autoescape(['html', 'xml'])
    )
    
    # Load and render template
    try:
        template = env.get_template(template_name)
        print(f"✅ Loaded template from {template_path}")
        
        # Render template with data
        html_output = template.render(**data)
        print("✅ Template rendered successfully")
        
        # Write output file
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_output)
        print(f"✅ Report generated: {output_path}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error rendering template: {e}")
        return False

def main():
    """Main function to handle command line arguments"""
    
    if len(sys.argv) != 4:
        print("Usage: python generate_report.py <template.html.j2> <data.json> <output.html>")
        print("\nExample:")
        print("  python generate_report.py aira_report_template.html.j2 sample_data.json output_report.html")
        sys.exit(1)
    
    template_path = sys.argv[1]
    data_path = sys.argv[2]
    output_path = sys.argv[3]
    
    print("🚀 AIRA Report Generator")
    print("=" * 50)
    print(f"Template: {template_path}")
    print(f"Data:     {data_path}")
    print(f"Output:   {output_path}")
    print("=" * 50)
    
    success = generate_report(template_path, data_path, output_path)
    
    if success:
        print("\n🎉 Report generation completed successfully!")
        print(f"📄 Open {output_path} in your browser to view the report")
    else:
        print("\n💥 Report generation failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()
